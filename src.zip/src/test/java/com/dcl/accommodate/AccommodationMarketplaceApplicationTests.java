package com.dcl.accommodate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccommodationMarketplaceApplicationTests {

	@Test
	void contextLoads() {
	}

}
