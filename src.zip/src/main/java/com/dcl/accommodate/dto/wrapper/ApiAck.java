package com.dcl.accommodate.dto.wrapper;

public record ApiAck(
        boolean success,
        String message
) {
}
