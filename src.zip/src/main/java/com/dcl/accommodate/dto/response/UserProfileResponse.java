package com.dcl.accommodate.dto.response;

import java.time.LocalDate;

public interface UserProfileResponse {


}
