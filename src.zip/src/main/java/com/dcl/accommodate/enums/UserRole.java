package com.dcl.accommodate.enums;

public enum UserRole {
    HOST,
    GUEST;
}
