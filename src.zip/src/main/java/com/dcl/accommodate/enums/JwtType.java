package com.dcl.accommodate.enums;

public enum JwtType {
    ACCESS,
    REFRESH
}
